package packageb

import (
	"log"
)

func Btask() {
	log.Println("B")
}
