package packageb

import (
	"fmt"
)

func Btask() {
	fmt.Println("B")
}
