package main

import (
	a "packagea"
)

func main() {
	a.Atask()
}

