package packagea

import b "packageb"

func Atask() {
	println("A")
	b.Btask()
}

