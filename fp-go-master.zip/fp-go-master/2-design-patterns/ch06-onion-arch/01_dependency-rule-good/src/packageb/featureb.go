package packageb

func Btask() {
	println("B")
}
