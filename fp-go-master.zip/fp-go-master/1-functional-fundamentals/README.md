For details and documenation of source code read the book, Learning Functional Programming in Go.

Book can be purchased at the following:

https://www.packtpub.com/application-development/learning-functional-programming-go
https://www.amazon.com/Learning-Functional-Programming-Lex-Sheehan-ebook/dp/B0725B8MYW
