package main

import (
	"math"
)

func main() {
	//a := 1.8
	//b := math.Floor(a + 1)
	//fmt.Println("b:", reflect.TypeOf(b))

	a := 1
	b := math.Floor(a + 1.8)
	println(b)


	//a := 1.8
	//println(a + 1)
	//
	//a := 1
	//b := a + 1.8
}
