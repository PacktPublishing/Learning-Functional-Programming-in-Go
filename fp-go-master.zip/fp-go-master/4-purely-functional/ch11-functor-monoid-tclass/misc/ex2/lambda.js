var add = function (a) {
    return function (b) {
        return a + b;
    };
};
add2 = add(2);

add2(1) == 6


const add = a => b => a + b;
add2 = add(2);
